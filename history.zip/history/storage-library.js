/*var saveData = function(key, value) {
       // Get a value saved in a form.
       //var theValue = textarea.value;
       // Check that there's some code there.
       if (!value) {
         alert('Error: No value specified');
         return;
       }
       // Save it using the Chrome extension storage API.
       chrome.storage.sync.set({key: value}, function() {
         // Notify that we saved.
         //alert(key + ' saved into chrome storage!');
       });
};*/

/*var getData = function(key) {
  if(!key) {
    alert('Error: No key mentioned to fetch value: ' + key);
    return null;
  }

  chrome.storage.sync.get(key, functon(data) {
    return data;
  });
};
*/
